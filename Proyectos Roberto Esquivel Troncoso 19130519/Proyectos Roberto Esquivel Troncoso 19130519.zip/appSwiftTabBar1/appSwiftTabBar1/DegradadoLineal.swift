//
//  DegradadoLineal.swift
//  appSwiftTabBar1
//
//  Created by Guest User on 06/12/22.
//

import UIKit

class DegradadoLineal: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        let canvas = UIGraphicsGetCurrentContext()
        canvas?.setLineWidth(3.0)
        // Gradientes
        let posicion : [CGFloat] = [0.0,0.25,0.75]
        
        //let colores = [UIColor.darkGray.cgColor, UIColor.green.cgColor, UIColor.blue.cgColor, UIColor.cyan.cgColor]
        
        let colores = [UIColor.brown.cgColor, UIColor.purple.cgColor, UIColor.orange.cgColor, UIColor.yellow.cgColor]
        let colorSpace1 = CGColorSpaceCreateDeviceRGB()
        let gradiente = CGGradient(colorsSpace: colorSpace1, colors: colores as CFArray, locations: posicion)
        
        var startPoint = CGPoint()
        var endPoint = CGPoint()
        startPoint.x = 0.0
        startPoint.y = 0.0
        endPoint.x = rect.width
        endPoint.y = rect.height
        
        canvas?.drawLinearGradient(gradiente!, start: startPoint, end: endPoint, options: .drawsBeforeStartLocation)
      
        // Curvas de bezier
        canvas?.move(to: CGPoint(x: 0, y: 0))
        canvas?.addCurve(to: CGPoint(x: rect.width-10, y: 400), control1: CGPoint(x: 20, y: 200), control2: CGPoint(x: rect.width-50, y: 50))
        canvas?.strokePath()
    }
    

}
