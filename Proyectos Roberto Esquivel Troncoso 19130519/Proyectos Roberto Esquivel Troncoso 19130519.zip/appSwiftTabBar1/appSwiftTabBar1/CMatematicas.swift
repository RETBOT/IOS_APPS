//
//  CMatematicas.swift
//  appSwiftTabBar1
//
//  Created by Guest User on 06/12/22.
//

import Foundation

class CMatematicas {
    // Suma
    static func Sumar (n1: Int, n2: Int) -> Int {
        let result =  n1 + n2
        return result
    }
    static func Sumar (n1: Double, n2: Double) -> Double {
        let result = n1 + n2
        return result
    }
    // Resta
    static func Resta (n1: Int, n2: Int) -> Int {
        return n1 - n2
    }
    static func Resta (n1: Double, n2: Double) -> Double {
        return n1 - n2
    }
    // Multi
    static func Multi (n1: Int, n2: Int) -> Int {
        return n1 * n2
    }
    static func Multi (n1: Double, n2: Double) -> Double {
        return n1 * n2
    }
    // Div
    static func Div (n1: Int, n2: Int) -> Int {
        return n1 / n2
    }
    static func Div (n1: Double, n2: Double) -> Double {
        return n1 / n2
    }
    // Modulo
    static func Mod (n1: Int, n2: Int) -> Int {
        return n1 % n2
    }
}
